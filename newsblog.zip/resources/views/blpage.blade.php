<?php
    use App\Blogitem;
?>
@extends('layouts.main')
@section('content')
    <div id="page_blog">
    <?php
        $blogitems= Blogitem::where('id','=',$id)->first();
    ?>
        <h1 class="h1_blog_page"><?php echo $blogitems->title; ?></h1>
        <div class="page_text">
            <?php echo $blogitems->text; ?>
        </div>
    </div>
@endsection

