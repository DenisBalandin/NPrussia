<?php
    use App\Blogitem;
?>

<?php $__env->startSection('content'); ?>
    <div class="news_items">
    <?php
        $blogitems= Blogitem::all();
        foreach ($blogitems as $blogitem){
            echo '
                <div class="news_item">
                    <h2><a href="/public/blpage/'.$blogitem->id.'">'.$blogitem->title.'</a></h2>
                    <div class="date"><a href="/blpage/'.$blogitem->id.'">'.$blogitem->date.'</a></div>
                    <div class="image">
                        <a href="/public/blpage/'.$blogitem->id.'"><img src="'.$blogitem->img.'"/></a>
                    </div>
                    <div class="item_text">'.$blogitem->text.'</div>
                    <div class="next_page">
                        <a href="/public/blpage/'.$blogitem->id.'">Дальше — больше 	&#8594; </a>
                    </div>
                </div>';
        }
    ?>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>