<?php
    use App\Blogitem;
?>

<?php $__env->startSection('content'); ?>
    <div id="page_blog">
    <?php
        $blogitems= Blogitem::where('id','=',$id)->first();
    ?>
        <h1 class="h1_blog_page"><?php echo $blogitems->title; ?></h1>
        <div class="page_text">
            <?php echo $blogitems->text; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>