<!DOCTYPE html>
<html>
<head>
    <title>Laravel</title>
    <link href="/public/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<!--Head-->
<div id="head_bg">
    <div id="head">
        <div class="my_name">Блог <a href="#"> Дениса Баландина</a></div>
        <a href="/"> <div class="blog_name">Непутевая Россия</div></a>
    </div>
</div>
<!--Head end-->
<div id="content">
    <div id="right_block">
        <div class="photoimage">
            <a href=""> <img src="/public/image/myphoto.jpg" width="170px"/></a>
            <div class="links_photo">
                <a href="#">Денис Баландин</a>
            </div>
            <div class="links_photo">
                <a href="#">ВКонтакте </a>
            </div>
            <div class="links_photo">
                <a href="#">Facebook </a>
            </div>
        </div>
        <div class="podpiska">
            <p>Подпишитесь на непутевую рассылку</p>
            <input class="podiskatext" type="text" value="Электронный адрес" name="podpiska"/>
            <input class="podpiskabutton" type="button" value="Подписаться">
        </div>

    </div>
    <div id="content_news">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>
<div id="footer_bg">
</div>
</body>

</html>