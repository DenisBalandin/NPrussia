<?php

namespace App\Http\Controllers;

use App\Model\Blogitem;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    function Welcome()
    {
        echo 'qwewq';
        //получаем все статьи из базы
        $articles=Blogitem::all();
        //полученные данные передаем в вид
        return view('welcome',['blogitem'=>$articles]);
    }
}
