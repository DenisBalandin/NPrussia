<?php
namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Blogitem;

class ArticleController extends Controller
{
    function ShowAll()
    {
        echo 'sdffd';
        //получаем все статьи из базы
        $articles=Blogitem::all();
        //полученные данные передаем в вид
        return view('article',['articles'=>$articles]);
    }
}