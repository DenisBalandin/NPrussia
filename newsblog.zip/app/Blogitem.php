<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

class Blogitem extends Model
{
    //article - это название таблицы в базе данных.
    protected $table='blogitem';
}